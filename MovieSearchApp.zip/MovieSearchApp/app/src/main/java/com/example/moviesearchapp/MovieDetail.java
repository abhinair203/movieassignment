package com.example.moviesearchapp;

public class MovieDetail {
    private String Title;
    private String Year;
    private String Director;

    private String type;
    private String posterUrl;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPosterUrl() {
        return posterUrl;
    }

    public void setPosterUrl(String posterUrl) {
        this.posterUrl = posterUrl;
    }

    public String getImdbId() {
        return imdbId;
    }

    public void setImdbId(String imdbId) {
        this.imdbId = imdbId;
    }

    private String imdbId;

    public MovieDetail(String imdbId,String title, String year, String director, String released, String runtime, String Type,String posterUri ,String plot) {
        Title = title;
        Year = year;
        Director = director;
        Released = released;
        Runtime = runtime;
        Plot = plot;
    }

    private String Released;
    private String Runtime;
    private String Plot;

    // Getters
    public String getTitle() { return Title; }
    public String getYear() { return Year; }
    public String getDirector() { return Director; }
    public String getReleased() { return Released; }
    public String getRuntime() { return Runtime; }
    public String getPlot() { return Plot; }

    // Setters
    public void setTitle(String title) { Title = title; }
    public void setYear(String year) { Year = year; }
    public void setDirector(String director) { Director = director; }
    public void setReleased(String released) { Released = released; }
    public void setRuntime(String runtime) { Runtime = runtime; }
    public void setPlot(String plot) { Plot = plot; }
}