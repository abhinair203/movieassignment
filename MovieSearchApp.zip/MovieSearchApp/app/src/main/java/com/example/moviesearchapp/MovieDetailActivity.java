package com.example.moviesearchapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;

public class MovieDetailActivity extends AppCompatActivity {
    private TextView titleTextView;
    private TextView yearTextView;
    private TextView directorTextView;
    private TextView releasedTextView;
    private TextView runtimeTextView;
    private TextView plotTextView;
    private ImageView posterImageView;
    private DBHandler dbHandler;
    private boolean isFavorite;
    private Button addToFavouriteBtn;
    String imdbId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.moviedetailactivity);

        titleTextView = findViewById(R.id.Title);
        yearTextView = findViewById(R.id.Year);
        directorTextView = findViewById(R.id.Director);
        releasedTextView = findViewById(R.id.Released);
        runtimeTextView = findViewById(R.id.Runtime);
        plotTextView = findViewById(R.id.Plot);
        posterImageView = findViewById(R.id.posterImageView);
        addToFavouriteBtn = findViewById(R.id.addFavoriteBtn);

        // Get data from intent
        String title = getIntent().getStringExtra("Title");
        String type = getIntent().getStringExtra("Type");
        String posterUrl = getIntent().getStringExtra("PosterUrl");
        imdbId = getIntent().getStringExtra("ImdbId");

        dbHandler = new DBHandler(this);

        // Set data to views
        titleTextView.setText(title);
        yearTextView.setText(type); // You may want to set the year here
        Glide.with(this)
                .load(posterUrl)
                .into(posterImageView);

        isFavorite = dbHandler.isMovieFavorite(imdbId);
        updateButton();

        // Fetch additional movie details
        gatherData(imdbId);
    }

    private void gatherData(String imdb) {
        OMDbApiCaller apiCaller = new OMDbApiCaller();
        apiCaller.fetchMovieData(imdb, new OMDbApiCaller.MovieResponseCallBack() {
            @Override
            public void onSuccess(MovieDetail movieDetail) {
                // Update your UI with the movie details
                titleTextView.setText(movieDetail.getTitle());
                yearTextView.setText(movieDetail.getYear());
                directorTextView.setText(movieDetail.getDirector());
                releasedTextView.setText(movieDetail.getReleased());
                runtimeTextView.setText(movieDetail.getRuntime());
                plotTextView.setText(movieDetail.getPlot());
            }

            @Override
            public void onError(String error) {
                // Handle the error
                Toast.makeText(getApplicationContext(), "Error: " + error, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateButton() {
        if (isFavorite) {
            addToFavouriteBtn.setText("Remove from Favorites");
        } else {
            addToFavouriteBtn.setText("Add to Favorites");
        }
    }

    public void addToFavouriteBtn(View view) {
        String title = titleTextView.getText().toString();
        String posterUrl = getIntent().getStringExtra("PosterUrl");
        String type = "Movie"; // Assuming type remains the same
        String year = yearTextView.getText().toString();
        String director = directorTextView.getText().toString();
        String released = releasedTextView.getText().toString();
        String runtime = runtimeTextView.getText().toString();
        String plot = plotTextView.getText().toString();

        if (isFavorite) {
            boolean isDeleted = dbHandler.deleteMovie(imdbId);
            if (isDeleted) {
                Toast.makeText(this, "Removed from Favorites", Toast.LENGTH_SHORT).show();
                isFavorite = false;
            } else {
                Toast.makeText(this, "Failed to Remove from Favorites", Toast.LENGTH_SHORT).show();
            }
        } else {
            // Add to favorites
            boolean isInserted = dbHandler.insertMovie(imdbId,title,type,posterUrl,year);
            if (isInserted) {
                Toast.makeText(this, "Added to Favorites", Toast.LENGTH_SHORT).show();
                isFavorite = true;
            } else {
                Toast.makeText(this, "Failed to Add to Favorites", Toast.LENGTH_SHORT).show();
            }
        }
        updateButton();
    }
}

