package com.example.moviesearchapp;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DBHandler extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "MovieData.db";
    private static final int DATABASE_VERSION = 2; // Incremented version
    private static final String TABLE_NAME = "MOVIE";
    private static final String COLUMN_IMDB_ID = "imdbId";
    private static final String COLUMN_TITLE = "title";
    private static final String COLUMN_TYPE = "type";
    private static final String COLUMN_POSTER_URL = "posterUrl";
    private static final String COLUMN_YEAR = "year";  // Added column

    public DBHandler(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME + " ("
                + COLUMN_IMDB_ID + " TEXT PRIMARY KEY, "  // Changed to PRIMARY KEY
                + COLUMN_TITLE + " TEXT, "
                + COLUMN_TYPE + " TEXT, "
                + COLUMN_POSTER_URL + " TEXT, "
                + COLUMN_YEAR + " TEXT)";  // Added column
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            // Dropping old table and creating new one with the new schema
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
            onCreate(db);
        }
    }

    public boolean insertMovie(String imdbId, String title, String type, String posterUrl, String year) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_IMDB_ID, imdbId);
        values.put(COLUMN_TITLE, title);
        values.put(COLUMN_TYPE, type);
        values.put(COLUMN_POSTER_URL, posterUrl);
        values.put(COLUMN_YEAR, year);  // Added column

        long result = db.insert(TABLE_NAME, null, values);
        db.close();
        return result != -1;
    }

    public List<Movie> getAllMovies() {
        List<Movie> movies = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);

        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") String imdbId = cursor.getString(cursor.getColumnIndex(COLUMN_IMDB_ID));
                @SuppressLint("Range") String title = cursor.getString(cursor.getColumnIndex(COLUMN_TITLE));
                @SuppressLint("Range") String type = cursor.getString(cursor.getColumnIndex(COLUMN_TYPE));
                @SuppressLint("Range") String posterUrl = cursor.getString(cursor.getColumnIndex(COLUMN_POSTER_URL));
                @SuppressLint("Range") String year = cursor.getString(cursor.getColumnIndex(COLUMN_YEAR));  // Added column
                movies.add(new Movie(imdbId, title, year,type, posterUrl));
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return movies;
    }

    public boolean isMovieFavorite(String imdbId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE " + COLUMN_IMDB_ID + "=?", new String[]{imdbId});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

    public boolean deleteMovie(String imdbId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsDeleted = db.delete(TABLE_NAME, COLUMN_IMDB_ID + "=?", new String[]{imdbId});
        db.close();
        return rowsDeleted > 0;
    }
}
