package com.example.moviesearchapp;


import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.androidnetworking.AndroidNetworking;

import java.io.IOException;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private EditText searchTxt;  // Changed to EditText
//    private RecyclerView recyclerView;
    private TextView resultsTxt;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        AndroidNetworking.initialize(getApplicationContext());
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        searchTxt = findViewById(R.id.searchTxt);
//        recyclerView = findViewById(R.id.recyclerContact);
//        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        resultsTxt=findViewById(R.id.resultstxt);
    }

    public void SearchBtn(View view) throws IOException {
        String searchText = searchTxt.getText().toString();


        if(searchText.isEmpty()){
            return;
        }
//        new FetchMoviesTask(resultsTxt).execute(searchText);
//        List<Movie> movieList=OMDbApiCaller.getResults(searchText);
//
        StringBuilder sb=new StringBuilder();
//        for (Movie m:movieList ) {
//            sb.append(m.toString());
//        }
//


        OMDbApiCaller.getResults("Avengers", new OMDbApiCaller.ResponseCallback() {
            @Override
            public void onSuccess(List<Movie> movies) {
                // Handle the list of movies
                for (Movie movie : movies) {
                    Log.d("Movie", "Title: " + movie.getTitle());
                    // Update UI with movie data
                    sb.append("Title: " + movie.getTitle() + "\n");
                }
            }

            @Override
            public void onError(String error) {
                // Handle the error
                Log.e("Movie", "Error: " + error);
            }
        });
        resultsTxt.setText(sb.toString());


        // Create and show an AlertDialog
//        new AlertDialog.Builder(this)
//                .setTitle("Search Result")
//                .setMessage(sb.toString())
//                .setPositiveButton("OK", null) // Add a button to dismiss the dialog
//                .show();
    }
}
