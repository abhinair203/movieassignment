package com.example.moviesearchapp;


import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.androidnetworking.AndroidNetworking;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private EditText searchTxt;  // Changed to EditText
    private RecyclerView recyclerContact;
    private ArrayList<Movie> movies=new ArrayList<>();
    MovieAdapter movieAdapter;
    private DBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        AndroidNetworking.initialize(getApplicationContext());
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        searchTxt = findViewById(R.id.searchTxt);

        recyclerContact = findViewById(R.id.recyclerContact);
        recyclerContact.setLayoutManager(new LinearLayoutManager(this));
        movieAdapter=new MovieAdapter(this,movies);
        recyclerContact.setAdapter(movieAdapter);

        dbHandler = new DBHandler(this);
        loadMoviesFromDatabase();

        // Add TextWatcher to searchTxt
        searchTxt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // No-op
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Trigger search when text changes
                if (s.length() > 2) {  // To avoid searching on every character, you can set a threshold
                    searchMovies(s.toString());
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                return;
            }


        });
    }
    private void loadMoviesFromDatabase() {
        List<Movie> moviesFromDb = dbHandler.getAllMovies();
        movies.clear();
        movies.addAll(moviesFromDb);
        movieAdapter.notifyDataSetChanged();
    }


    private void searchMovies(String s){
        OMDbApiCaller.getResults(s, new OMDbApiCaller.ResponseCallback() {
            @Override
            public void onSuccess(List<Movie> movies) {
                movieAdapter.updateMovies(movies);
            }

            @Override
            public void onError(String error) {
                // Handle the error
                Log.e("Movie", "Error: " + error);
            }
        });
    }

    public void GoToFavorite(View view){
        Intent intent = new Intent(MainActivity.this, FavoritesActivity.class);
        startActivity(intent);
    }
}
