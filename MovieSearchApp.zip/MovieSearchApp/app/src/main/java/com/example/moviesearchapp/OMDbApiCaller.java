package com.example.moviesearchapp;

import android.util.Log;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class OMDbApiCaller {

    private static final String API_KEY = "c60597b";
    public interface ResponseCallback {
        void onSuccess(List<Movie> movies);

        void onError(String error);
    }
    public interface MovieResponseCallBack{
        void onSuccess(MovieDetail movie);

        void onError(String error);
    }

    public static CompletableFuture<ArrayList<Movie>> getResults(String search, ResponseCallback callback) {
        CompletableFuture<ArrayList<Movie>> future = new CompletableFuture<>();

        fetchData(search, new ResponseCallback() {
            @Override
            public void onSuccess(List<Movie> movies) {
                future.complete(new ArrayList<>(movies));
                callback.onSuccess(movies); // Optionally call the callback directly
            }

            @Override
            public void onError(String error) {
                future.completeExceptionally(new Exception(error));
            }
        });

        return future;
    }

    private static void fetchData(String search, ResponseCallback callback) {
        String url = "https://www.omdbapi.com/?apikey=" + API_KEY + "&s=" + search;

        AndroidNetworking.get(url)
                .setPriority(Priority.HIGH)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d("Search", response.toString());

                        // Parse JSON response
                        Gson gson = new Gson();
                        Type responseType = new TypeToken<OMDBResponse>() {
                        }.getType();
                        OMDBResponse omdbResponse = gson.fromJson(response.toString(), responseType);

                        if (omdbResponse != null && omdbResponse.getSearch() != null) {
                            callback.onSuccess(omdbResponse.getSearch());
                        } else {
                            callback.onError("No data found.");
                        }
                    }

                    @Override
                    public void onError(ANError anError) {
                        Log.e("Search", "Error: " + anError.getMessage());
                        callback.onError("Error fetching data.");
                    }
                });
    }


    public static void fetchMovieData(String imdbId, MovieResponseCallBack callback) {
        String url = "https://www.omdbapi.com/?i=" + imdbId + "&apikey=" + API_KEY;

        AndroidNetworking.get(url)
                .setPriority(Priority.HIGH)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d("MovieDetails", response.toString());

                        // Parse JSON response
                        Gson gson = new Gson();
                        MovieDetail movieDetail = gson.fromJson(response.toString(), MovieDetail.class);

                        if (movieDetail != null) {
                            callback.onSuccess(movieDetail);
                        } else {
                            callback.onError("No data found.");
                        }
                    }

                    @Override
                    public void onError(ANError anError) {
                        Log.e("MovieDetails", "Error: " + anError.getMessage());
                        callback.onError("Error fetching data.");
                    }
                });
    }
}