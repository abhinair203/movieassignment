package com.example.moviesearchapp;

import android.util.Log;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONArrayRequestListener;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.example.moviesearchapp.OMDBResponse;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

public class OMDbApiCaller {

    private static final String API_KEY = "yourkey";  // Replace with your actual API key

    //    public static void main(String[] args) {
//        try {
//            OMDBResponse response = fetchFromOMDbApi("Avengers", null, "movie", null, "short", "json", null, 1);
//            List<Movie> movies = response.getSearch();
//            for (Movie movie : movies) {
//                System.out.println("Title: " + movie.getTitle());
//                System.out.println("Year: " + movie.getYear());
//                System.out.println("IMDB ID: " + movie.getImdbID());
//                System.out.println("Type: " + movie.getType());
//                System.out.println("Poster: " + movie.getPoster());
//                System.out.println();
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//    public static List<Movie> getResults(String search) throws IOException {
//        return fetchData().getSearch();
//    }
//    private static OMDBResponse fetchFromOMDbApi(String title) throws IOException {
//        // Build the URL
//        StringBuilder urlBuilder = new StringBuilder("https://www.omdbapi.com/?apikey=" + API_KEY);
//
//
//        if (title != null && !title.isEmpty()) {
//            urlBuilder.append("&s=").append(title);
//        }
//        // Create URL object
//        URL url = new URL(urlBuilder.toString());
//
//        // Open connection
//        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
//        conn.setRequestMethod("GET");
//
//        // Read response
//        BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
//        String inputLine;
//        StringBuilder response = new StringBuilder();
//
//        while ((inputLine = in.readLine()) != null) {
//            response.append(inputLine);
//        }
//
//        in.close();
//
//        // Parse JSON response
//        Gson gson = new Gson();
//        Type responseType = new TypeToken<OMDBResponse>() {}.getType();
//        return gson.fromJson(response.toString(), responseType);
//    }
    // Callback interface to handle the response
    public interface ResponseCallback {
        void onSuccess(List<Movie> movies);

        void onError(String error);
    }

    public static void getResults(String search, ResponseCallback callback) {
        fetchData(search, callback);
    }

    private static void fetchData(String search, ResponseCallback callback) {
        String url = "https://www.omdbapi.com/?apikey=" + API_KEY + "&s=" + search;

        AndroidNetworking.get(url)
                .setPriority(Priority.HIGH)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d("Search", response.toString());

                        // Parse JSON response
                        Gson gson = new Gson();
                        Type responseType = new TypeToken<OMDBResponse>() {
                        }.getType();
                        OMDBResponse omdbResponse = gson.fromJson(response.toString(), responseType);

                        if (omdbResponse != null && omdbResponse.getSearch() != null) {
                            callback.onSuccess(omdbResponse.getSearch());
                        } else {
                            callback.onError("No data found.");
                        }
                    }

                    @Override
                    public void onError(ANError anError) {
                        Log.e("Search", "Error: " + anError.getMessage());
                        callback.onError("Error fetching data.");
                    }
                });
    }
}